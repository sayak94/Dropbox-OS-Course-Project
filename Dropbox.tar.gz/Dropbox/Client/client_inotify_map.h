int getDirPath(char *fileName , char *dirPath , int wd);
int addDirPath(char *fileName , char *dirPath , int wd);
int *deleteDirPath(char *fileName , char *dirPathToBeDeleted);
