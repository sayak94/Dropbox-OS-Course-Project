void SendClientFileCreated(int, char *, char *, char *);
void SendClientFileModified(int, char *, char *, char *);
void SendClientFileDeleted(int, char *, char *, char *);
void SendClientFileMovedFrom(int, char *, char *, char *);
void SendClientFileMovedTo(int, char *, char *, char *);
void SendClientFolderDeleted(int, char *, char *, char *);
void SendClientFolderCreated(int, char *, char *, char *);
