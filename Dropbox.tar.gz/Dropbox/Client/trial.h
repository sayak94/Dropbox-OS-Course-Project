int monitor(DIR *, char *, int, char *);
int inotify_setup(char * , int);
